import{default as t}from"../components/pages/_page.svelte-b502142d.js";export{t as component};
