import{default as t}from"../components/pages/channel/_page.svelte-a827bf54.js";export{t as component};
