import{default as t}from"../components/pages/channel/_page.svelte-be2bdf96.js";export{t as component};
