import{default as t}from"../components/pages/_page.svelte-79627a7d.js";export{t as component};
