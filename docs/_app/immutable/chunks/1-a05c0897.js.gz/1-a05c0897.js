import{default as t}from"../components/error.svelte-d45d2747.js";export{t as component};
