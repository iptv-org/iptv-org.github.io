import{default as t}from"../components/pages/_page.svelte-90c41a04.js";export{t as component};
