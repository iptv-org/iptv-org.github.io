import{default as t}from"../components/pages/channel/_page.svelte-d194e74b.js";export{t as component};
