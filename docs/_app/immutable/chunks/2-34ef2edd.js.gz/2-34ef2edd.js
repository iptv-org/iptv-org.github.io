import{default as t}from"../components/pages/_page.svelte-f8a4fad1.js";export{t as component};
