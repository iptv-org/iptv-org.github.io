import{default as t}from"../components/pages/channel/_page.svelte-68758a63.js";export{t as component};
