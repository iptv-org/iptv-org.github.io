import{default as t}from"../components/pages/channel/_page.svelte-37398ba2.js";export{t as component};
