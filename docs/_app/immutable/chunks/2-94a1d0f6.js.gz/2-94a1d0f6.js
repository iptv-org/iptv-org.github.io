import{default as t}from"../components/pages/_page.svelte-fc44449c.js";export{t as component};
