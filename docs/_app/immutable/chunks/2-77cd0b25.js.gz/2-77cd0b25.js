import{default as t}from"../components/pages/_page.svelte-b1784de1.js";export{t as component};
