import{default as t}from"../components/pages/_page.svelte-89a06bc0.js";export{t as component};
